function [TB] = perform_optimization_DataBase(n,D0,Df_S,nlm,Df_UM,pt_save)



for ktest=1:1:length(Tests)
    time_A = cputime;
    Chosen = Tests{ktest};
    [P_Var,D,t,Tau,d] = Reading_Data_Base(Chosen,DB_path,Df_S);
    [ID] = Compute_slab_characteristics(P_Var.eta0DS,Df_S,n,P_Var.L0,P_Var.s0,D0,P_Var.eta0DM,Df_UM,nlm);
    % Example
    if P_Var.failed == 0
        f = [double(-d./2),0.0];
        fun      = @(x) optimizing_fit(ID,nlm,x,D,t);
        f    = fminsearch(fun,f);

        ID.ID_A.fetch(1) = abs(f(1));
        ID.ID_A.fetch(2) = abs(f(2));
        [TestData] = Run_Simulation_DragA(ID.ID_A,nlm);
        [D,D_0D2D] = clean_data(TestData,D,t);
        res = goodnessOfFit(D,D_0D2D,'NMSE');

%         
%         figure(1)
%         name_picture = (['AT_',num2str(ktest),'D_t']);
%         plot(n.*t,D,'Color','k',LineStyle='-.',LineWidth=1.2)
%         hold on
%         plot(n.*t,D_0D2D,'Color','b',LineStyle='-.',LineWidth=1.2)
%         title_plot = (['Test',num2str(ktest), ' $\Lambda$ = ', num2str(ID.ID_A.Lambda)]);
%         title(title_plot,Interpreter="latex")
%         xlim([0,10])
%         ylim([0.1,1.0])
%         legend('2D numerical experiment','0D numerical experiment')
%         grid on
%         xlabel('$\frac{n\cdot t}{t_c}$',Interpreter='latex')
%         ylabel('$\frac{D}{D_0}$',Interpreter='latex')
%         pt=fullfile(pt_save,name_picture);
%         print(pt,'-dpng')
%         clf; 
% 
%         figure(2)
%         name_picture = (['BT_',num2str(ktest),'DIFF']);
%         plot(n.*t,D-D_0D2D)
%         xlim([0,10])
%         title_plot = (['Test $D_{2D}-D_{0D}$',num2str(ktest), '$\Lambda$ = ', num2str(ID.ID_A.Lambda)]);
%         title(title_plot,Interpreter="latex")
% 
%         grid on
%         xlabel('$\frac{n\cdot t}{t_c}$',Interpreter='latex')
%         ylabel('$\frac{D_{2D}-D_{0D}}{D_0}$',Interpreter='latex')
%         pt=fullfile(pt,name_picture);
%         print(pt_save,'-dpng')
%         clf;

        disp(['The test @ node ', Chosen, ' show a ',num2str(res*100), ' % fit'])
        Lambda(suc)=ID.ID_A.Lambda;
        fitting_p(suc)=res;
        fetch(suc,1)=f(1); 
        fetch(suc,2)=f(2); 
        eta0DM(suc)=P_Var.eta0DM;
        L0(suc)= P_Var.L0;
        s0(suc)=P_Var.s0;
        T(suc,:)=Tau; 
        Dp(suc) = d; 
        suc = suc+1; 

    else
        disp('=====================================================================')
        disp(['You cannot optimize a failure, but, i can give you motivational tips:'])
        disp([ ' it is not always good being consistent in failing'])
        disp('So long and thanks for all the fish')
        disp('=====================================================================')
        f = nan;
        t = [];
        D = [];
        D_0D2D = [];
    end
    TB.(strcat('T',num2str(ktest))).ID = ID.ID_A;
    TB.(strcat('T',num2str(ktest))).P_Var = P_Var;
    TB.(strcat('T',num2str(ktest))).D = D;
    TB.(strcat('T',num2str(ktest))).t = t;
    TB.(strcat('T',num2str(ktest))).D0D2 = D_0D2D;
    TB.(strcat('T',num2str(ktest))).f = f;
    TB.(strcat('T',num2str(ktest))).res = res;

    B = cputime; 
    time_ktest = (B-time_A)/60;

    disp(['The test @ node ', Chosen, ' took ', num2str(time_ktest),' minutes'])

end
end